### R code from vignette source 'KoreanProjection-vignettes.Rnw'
### Encoding: CP949

###################################################
### code chunk number 1: KoreanProjection-vignettes.Rnw:27-28
###################################################
  if(exists(".orig.enc")) options(encoding = .orig.enc)


